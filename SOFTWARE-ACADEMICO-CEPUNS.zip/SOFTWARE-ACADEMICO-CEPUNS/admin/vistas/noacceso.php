    <div class="content-wrapper">
    <section class="content">
      <div class="row">
        <div class="col-md-12">
      <div class="box">
<div class="box-header with-border">
  <h1 class="box-title">Sin acceso</h1>
  <div class="box-tools pull-right">
  </div>
</div>
      </div>
      </div>
      </div>
    </section>
  </div>

