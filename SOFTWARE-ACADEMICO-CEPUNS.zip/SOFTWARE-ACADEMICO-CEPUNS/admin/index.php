<?php 
//redireccionar a la vista de login que se encuentra en la carpeta admin/vistas

header('location: vistas/login.html');
 ?>