<?php
include('menu.php');
?>

<div class="container" style="padding: 40px;">
 
    
    
  <div class="row" >
    <div class="col-md-2"></div>
  <div class="col-md-4">
  	<img src="../cepuns.png" style="border-radius: 10px;padding: 0px;"></div>
  	<br>

  	<div class="col-md-4 text-justify" >Hola <b>

  		<?php echo $_SESSION["s_usuario"]; ?>
  			
  		</b> a continuación la plataforma le brinda el acceso a la visualizacion de tus asistencias y registros de notas durante este periodo. 

  		<br> Recuerde no compartir sus datos personales. <br>
  		<center>Gracias.</center> 
  	</div>
  <div class="col-md-2"></div>
</div>
  
</div>