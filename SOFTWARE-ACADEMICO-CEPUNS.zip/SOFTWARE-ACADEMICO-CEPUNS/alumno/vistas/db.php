<?php

$conex = mysqli_connect("localhost","root","Root2024","CEPUNS"); 

?>