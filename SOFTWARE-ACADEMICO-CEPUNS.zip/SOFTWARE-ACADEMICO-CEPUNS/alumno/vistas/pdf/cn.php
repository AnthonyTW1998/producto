<?php

$mysqli = new mysqli("","root","","cepuns");
?>